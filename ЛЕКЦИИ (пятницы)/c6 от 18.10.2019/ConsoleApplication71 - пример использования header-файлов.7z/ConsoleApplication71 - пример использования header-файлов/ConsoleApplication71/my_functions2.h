#include "my_functions.h"

namespace my_namespace{
	int sum4(int a, int b, int c, int d){
		return sum3(a, b, c) + d;
	}
}