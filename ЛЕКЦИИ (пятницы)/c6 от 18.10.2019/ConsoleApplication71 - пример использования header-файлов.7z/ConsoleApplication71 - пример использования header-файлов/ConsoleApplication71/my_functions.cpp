#include "stdafx.h"
#include "my_functions.h"

void printArr(int *mas, int N){
	for (int i = 0; i < N; i++)
		std::cout << mas[i] << '\t';
	std::cout << std::endl;
}

void printHello(){
	std::cout << "Hello" << std::endl;
}

int sum3(int a, int b, int c){
	return a + b + c;
}

int GCD(int x, int y)
{
	while (x != 0 && y != 0){
		if (x > y) x = x % y; // x %= y;
		else y = y % x;
	}
	return (y == 0) ? x : y;
}