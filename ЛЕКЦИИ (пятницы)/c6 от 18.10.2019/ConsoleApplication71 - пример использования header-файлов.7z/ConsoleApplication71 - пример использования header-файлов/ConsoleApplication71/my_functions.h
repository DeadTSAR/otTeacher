#pragma once
#include <iostream>

void printArr(int *mas, int N);

void printHello();

int sum3(int a, int b = 7, int c = 8);

int GCD(int x, int y);